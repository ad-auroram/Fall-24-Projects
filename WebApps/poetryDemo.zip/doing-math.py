import numpy as np

print(np.sin(2))
